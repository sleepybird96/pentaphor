# PENTAPHOR quest art

12 preset human-action illustrations. Created with the built-in image generation tool.

Direction: featureless signage people; detailed action props and expressive poses; ivory, teal and ink palette with restrained gold accents. Individual square images for quest selection and achievement views.

Prompts are recorded in `prompts.json`. Generated output properties and final filenames are recorded in `manifest.json` after inspection.

Final delivery: 12 individually generated 1254 × 1254 PNG images with opaque dark ink backgrounds (not transparent cutouts). Open index.html for a labeled gallery. Generated backgrounds may have subtle texture/color variation, so use as square art tiles. No app integration or animation is included.
